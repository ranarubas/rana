# Majestic Arabian
Static site. No build step. Edit WHATSAPP and PRODUCTS at the top of script.js.
