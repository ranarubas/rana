// ====== EDIT THESE ======
const WHATSAPP = "923001234567"; // your number, country code first, no + or spaces
const CURRENCY = "Rs";
const PRODUCTS = [
  {id:1,name:"Brass Arabian Lantern",cat:"Lighting",price:6500,c:["#B8893B","#7a5a22"]},
  {id:2,name:"Carved Wooden Wall Panel",cat:"Wall decor",price:9800,c:["#5A2A3A","#3a1824"]},
  {id:3,name:"Calligraphy Canvas Set",cat:"Wall decor",price:7200,c:["#0F3B3A","#072120"]},
  {id:4,name:"Woven Majlis Cushion Pair",cat:"Textiles",price:3800,c:["#8a4b2d","#5a2f1a"]},
  {id:5,name:"Incense Burner (Mabkhara)",cat:"Lifestyle",price:2900,c:["#2c2a26","#111"]},
  {id:6,name:"Moroccan Mosaic Table Lamp",cat:"Lighting",price:8400,c:["#154c4a","#0a2a29"]},
  {id:7,name:"Arabic Coffee Dallah Set",cat:"Lifestyle",price:11500,c:["#B8893B","#5a4116"]},
  {id:8,name:"Embroidered Table Runner",cat:"Textiles",price:2600,c:["#5A2A3A","#8a4b2d"]}
];
// ========================
const $ = id => document.getElementById(id);
const money = n => CURRENCY + " " + n.toLocaleString("en-US");
let cart = {};
try { cart = JSON.parse(localStorage.getItem("ma-cart")) || {}; } catch(e) {}
let filter = "All";

function renderFilters(){
  const cats = ["All", ...new Set(PRODUCTS.map(p => p.cat))];
  $("filters").innerHTML = cats.map(c => `<button class="${c===filter?"on":""}" data-c="${c}">${c}</button>`).join("");
  $("filters").querySelectorAll("button").forEach(b => b.onclick = () => { filter = b.dataset.c; renderFilters(); renderGrid(); });
}
function renderGrid(){
  const list = PRODUCTS.filter(p => filter==="All" || p.cat===filter);
  $("grid").innerHTML = list.map(p => `
    <article class="card">
      <div class="art" style="background:linear-gradient(135deg,${p.c[0]},${p.c[1]})">${p.name[0]}</div>
      <h4>${p.name}</h4><div class="cat">${p.cat}</div>
      <div class="row"><span class="price">${money(p.price)}</span><button data-id="${p.id}">Add to cart</button></div>
    </article>`).join("");
  $("grid").querySelectorAll("button").forEach(b => b.onclick = () => add(+b.dataset.id));
}
function save(){ try { localStorage.setItem("ma-cart", JSON.stringify(cart)); } catch(e) {} renderCart(); }
function add(id){ cart[id] = (cart[id]||0) + 1; save(); openDrawer(); }
function change(id,d){ cart[id] = (cart[id]||0) + d; if(cart[id] <= 0) delete cart[id]; save(); }
function renderCart(){
  const ids = Object.keys(cart);
  let total = 0, count = 0;
  $("items").innerHTML = ids.length ? ids.map(id => {
    const p = PRODUCTS.find(x => x.id == id); if(!p) return "";
    const q = cart[id]; total += p.price*q; count += q;
    return `<div class="line"><div>${p.name}<small>${money(p.price)}</small>
      <div class="qty"><button data-id="${id}" data-d="-1" aria-label="Less">-</button>${q}<button data-id="${id}" data-d="1" aria-label="More">+</button></div></div>
      <strong>${money(p.price*q)}</strong></div>`;
  }).join("") : `<p class="empty">Your cart is empty. Add a piece from the collection.</p>`;
  $("items").querySelectorAll(".qty button").forEach(b => b.onclick = () => change(b.dataset.id, +b.dataset.d));
  $("total").textContent = money(total);
  $("count").textContent = count;
}
function openDrawer(){ $("drawer").classList.add("on"); $("overlay").classList.add("on"); }
function closeDrawer(){ $("drawer").classList.remove("on"); $("overlay").classList.remove("on"); }
$("openCart").onclick = openDrawer;
$("closeCart").onclick = closeDrawer;
$("overlay").onclick = closeDrawer;
document.addEventListener("keydown", e => { if(e.key==="Escape") closeDrawer(); });
$("checkout").onclick = () => {
  const ids = Object.keys(cart);
  if(!ids.length){ alert("Your cart is empty."); return; }
  let total = 0;
  const lines = ids.map(id => { const p = PRODUCTS.find(x => x.id == id); total += p.price*cart[id]; return `- ${p.name} x${cart[id]} (${money(p.price*cart[id])})`; });
  const msg = `Hello Majestic Arabian, I want to order:\n${lines.join("\n")}\nTotal: ${money(total)}\nName:\nCity:\nAddress:`;
  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank");
};
$("waLink").href = `https://wa.me/${WHATSAPP}`;
renderFilters(); renderGrid(); renderCart();
